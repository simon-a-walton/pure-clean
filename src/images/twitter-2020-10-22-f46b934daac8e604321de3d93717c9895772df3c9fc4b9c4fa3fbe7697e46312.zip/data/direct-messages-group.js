window.YTD.direct_messages_group.part0 = [ {
  "dmConversation" : {
    "conversationId" : "640762934029885440",
    "messages" : [ {
      "messageCreate" : {
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "Great 😊",
        "mediaUrls" : [ ],
        "senderId" : "51741625",
        "id" : "640954746682101764",
        "createdAt" : "2015-09-07T18:28:14.649Z"
      }
    }, {
      "messageCreate" : {
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "The release is planned for 2016... Soon a preview of all the tracks mixed and masterd!",
        "mediaUrls" : [ ],
        "senderId" : "1217170945",
        "id" : "640950170037960707",
        "createdAt" : "2015-09-07T18:10:03.490Z"
      }
    }, {
      "messageCreate" : {
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "Any news on the track I sung on?",
        "mediaUrls" : [ ],
        "senderId" : "51741625",
        "id" : "640831760058687491",
        "createdAt" : "2015-09-07T10:19:32.349Z"
      }
    }, {
      "messageCreate" : {
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "Tnx a lot guys!!!!🙌",
        "mediaUrls" : [ ],
        "senderId" : "1217170945",
        "id" : "640830359156981763",
        "createdAt" : "2015-09-07T10:13:58.355Z"
      }
    }, {
      "messageCreate" : {
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "Really nice! Great 90s vibe. Good job guys",
        "mediaUrls" : [ ],
        "senderId" : "1044385958",
        "id" : "640819225783877635",
        "createdAt" : "2015-09-07T09:29:43.945Z"
      }
    }, {
      "messageCreate" : {
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "Very cool 😊",
        "mediaUrls" : [ ],
        "senderId" : "51741625",
        "id" : "640768856978493443",
        "createdAt" : "2015-09-07T06:09:35.087Z"
      }
    }, {
      "messageCreate" : {
        "reactions" : [ ],
        "urls" : [ {
          "url" : "http://t.co/MFj82tMmyL",
          "expanded" : "https://twitter.com/mastermainmusic/status/640560541723963392",
          "display" : "twitter.com/mastermainmusi…"
        } ],
        "text" : "Our first remix... Your opinion is very important for us. Please listen🎵 http://t.co/MFj82tMmyL",
        "mediaUrls" : [ ],
        "senderId" : "1217170945",
        "id" : "640762934029885443",
        "createdAt" : "2015-09-07T05:46:03.038Z"
      }
    }, {
      "joinConversation" : {
        "initiatingUserId" : "1217170945",
        "participantsSnapshot" : [ "39066509", "51741625", "1044385958", "1217170945", "111622431" ],
        "createdAt" : "2015-09-07T05:46:03.038Z"
      }
    } ]
  }
} ]