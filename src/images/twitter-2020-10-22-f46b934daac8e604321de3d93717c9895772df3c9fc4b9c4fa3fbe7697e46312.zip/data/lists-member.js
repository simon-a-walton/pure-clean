window.YTD.lists_member.part0 = [ {
  "userListInfo" : {
    "url" : "https://twitter.com/TheOfficeGroup/lists/the-good-the-great"
  }
}, {
  "userListInfo" : {
    "url" : "https://twitter.com/HiddenTracksUK/lists/london-singers"
  }
}, {
  "userListInfo" : {
    "url" : "https://twitter.com/CityAcademyUK/lists/twitter-writers-club"
  }
}, {
  "userListInfo" : {
    "url" : "https://twitter.com/CityAcademyUK/lists/great-actors"
  }
}, {
  "userListInfo" : {
    "url" : "https://twitter.com/hrstump/lists/s2md"
  }
}, {
  "userListInfo" : {
    "url" : "https://twitter.com/sandracrespo/lists/london"
  }
}, {
  "userListInfo" : {
    "url" : "https://twitter.com/dannation/lists/friends"
  }
}, {
  "userListInfo" : {
    "url" : "https://twitter.com/anjelhuman/lists/enter-star-s"
  }
}, {
  "userListInfo" : {
    "url" : "https://twitter.com/anjelhuman/lists/happysmile1"
  }
} ]