window.YTD.email_address_change.part0 = [ {
  "emailAddressChange" : {
    "accountId" : "1044385958",
    "emailChange" : {
      "changedAt" : "2012-12-29T11:40:21.000Z",
      "changedTo" : "simonwaltontv@gmail.com"
    }
  }
} ]