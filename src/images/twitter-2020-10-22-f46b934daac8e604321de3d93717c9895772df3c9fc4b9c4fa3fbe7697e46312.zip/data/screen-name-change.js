window.YTD.screen_name_change.part0 = [ {
  "screenNameChange" : {
    "accountId" : "1044385958",
    "screenNameChange" : {
      "changedAt" : "2013-01-21T12:26:50.000Z",
      "changedFrom" : "fredoskar",
      "changedTo" : "fredoskar1111"
    }
  }
}, {
  "screenNameChange" : {
    "accountId" : "1044385958",
    "screenNameChange" : {
      "changedAt" : "2013-02-21T09:38:11.000Z",
      "changedFrom" : "fredoskar1111",
      "changedTo" : "iveneverfelt"
    }
  }
}, {
  "screenNameChange" : {
    "accountId" : "1044385958",
    "screenNameChange" : {
      "changedAt" : "2013-04-21T14:57:32.000Z",
      "changedFrom" : "iveneverfelt",
      "changedTo" : "simonwaltontv"
    }
  }
} ]