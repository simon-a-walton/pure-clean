window.YTD.verified.part0 = [ {
  "verified" : {
    "accountId" : "1044385958",
    "verified" : false
  }
} ]