window.YTD.connected_application.part0 = [ {
  "connectedApplication" : {
    "organization" : {
      "name" : "RedWigWam",
      "url" : "https://www.redwigwam.com"
    },
    "name" : "RedWigWam",
    "description" : "We allow our Workers ",
    "permissions" : [ "read" ],
    "approvedAt" : "2016-02-26T08:29:56.000Z",
    "id" : "7049483"
  }
}, {
  "connectedApplication" : {
    "organization" : {
      "name" : "",
      "url" : ""
    },
    "name" : "4Shared",
    "description" : "Free file sharing",
    "permissions" : [ "read", "write" ],
    "approvedAt" : "2013-12-17T22:29:42.000Z",
    "id" : "145479"
  }
}, {
  "connectedApplication" : {
    "organization" : {
      "name" : "NationBuilder",
      "url" : "http://nationbuilder.com/"
    },
    "name" : "NationBuilder",
    "description" : "Turn your life into a movement.",
    "permissions" : [ "read", "write" ],
    "approvedAt" : "2014-02-25T10:05:51.000Z",
    "id" : "370349"
  }
}, {
  "connectedApplication" : {
    "organization" : {
      "name" : "Apple®",
      "url" : ""
    },
    "name" : "iOS",
    "description" : "iOS Twitter integration",
    "permissions" : [ "read", "write" ],
    "approvedAt" : "2015-06-05T18:54:54.000Z",
    "id" : "312240"
  }
}, {
  "connectedApplication" : {
    "organization" : {
      "name" : "Spotify",
      "url" : "https://www.spotify.com"
    },
    "name" : "Spotify for Artists",
    "description" : "Your music’s out there. We’ll show you who’s listening.",
    "permissions" : [ "read" ],
    "approvedAt" : "2018-03-13T15:36:25.000Z",
    "id" : "13517514"
  }
}, {
  "connectedApplication" : {
    "organization" : {
      "name" : "Twitter",
      "url" : ""
    },
    "name" : "Twitter for iPhone",
    "description" : "Twitter for iPhone",
    "permissions" : [ "read", "write" ],
    "approvedAt" : "2015-06-05T18:54:52.000Z",
    "id" : "129032"
  }
}, {
  "connectedApplication" : {
    "organization" : {
      "name" : "Google Inc",
      "url" : "https://www.google.com/",
      "privacyPolicyUrl" : "https://policies.google.com/privacy",
      "termsAndConditionsUrl" : "https://policies.google.com/terms"
    },
    "name" : "Google",
    "description" : "Google/Twitter integration.",
    "permissions" : [ "read", "write" ],
    "approvedAt" : "2016-04-23T13:19:37.000Z",
    "id" : "8719"
  }
}, {
  "connectedApplication" : {
    "organization" : {
      "name" : "Apple®",
      "url" : ""
    },
    "name" : "OS X",
    "description" : "OS X Twitter integration",
    "permissions" : [ "read", "write" ],
    "approvedAt" : "2015-07-08T12:28:08.000Z",
    "id" : "1535234"
  }
}, {
  "connectedApplication" : {
    "organization" : {
      "name" : "Instagram, Inc.",
      "url" : "http://instagram.com"
    },
    "name" : "Instagram",
    "description" : "Instagram is a fast, beautiful and fun way to share your photos with friends and family.",
    "permissions" : [ "read", "write" ],
    "approvedAt" : "2014-03-16T14:30:44.000Z",
    "id" : "239954"
  }
}, {
  "connectedApplication" : {
    "organization" : {
      "name" : "Twitter, Inc.",
      "url" : ""
    },
    "name" : "Twitter for Android",
    "description" : "Twitter for Android",
    "permissions" : [ "read", "write" ],
    "approvedAt" : "2013-11-11T16:48:38.000Z",
    "id" : "258901"
  }
}, {
  "connectedApplication" : {
    "organization" : {
      "name" : "",
      "url" : ""
    },
    "name" : "House Of Mask ",
    "description" : "Discover The Spirit Within",
    "permissions" : [ "read", "write" ],
    "approvedAt" : "2014-11-01T00:59:27.000Z",
    "id" : "5970736"
  }
}, {
  "connectedApplication" : {
    "organization" : {
      "name" : "",
      "url" : ""
    },
    "name" : "RSN-Tickets",
    "description" : "Securely purchase gig, comedy and festival tickets for venues in London and the rest of the World.",
    "permissions" : [ "read", "write" ],
    "approvedAt" : "2015-02-02T17:05:17.000Z",
    "id" : "5360824"
  }
} ]