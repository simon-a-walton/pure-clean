window.YTD.account.part0 = [ {
  "account" : {
    "email" : "simonwaltontv@gmail.com",
    "createdVia" : "web",
    "username" : "simonwaltontv",
    "accountId" : "1044385958",
    "createdAt" : "2012-12-29T10:02:40.000Z",
    "accountDisplayName" : "Simon Walton"
  }
} ]