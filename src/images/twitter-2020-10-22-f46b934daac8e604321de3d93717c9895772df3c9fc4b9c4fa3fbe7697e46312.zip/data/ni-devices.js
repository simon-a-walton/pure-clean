window.YTD.ni_devices.part0 = [ {
  "niDeviceResponse" : {
    "pushDevice" : {
      "udid" : "F9F529F0-1F71-471A-83C4-773A0559BF86",
      "deviceType" : "Twitter for iOS",
      "token" : "L3/o9D3DMDHIf+Gme+zqahpbqlINc/pLLaSV2GVLF8A=",
      "updatedDate" : "2016.09.05",
      "createdDate" : "2015.06.05"
    }
  }
}, {
  "niDeviceResponse" : {
    "pushDevice" : {
      "deviceVersion" : "7.58.5",
      "udid" : "60D9CC5B-FA4C-40CA-A680-63EC843AB422",
      "deviceType" : "Twitter for iOS",
      "token" : "LYHIWuWDZ0DS2P3ryf/I2FCOmmA/MOZH6VTulo0DafM=",
      "updatedDate" : "2019.09.15",
      "createdDate" : "2018.05.14"
    }
  }
} ]