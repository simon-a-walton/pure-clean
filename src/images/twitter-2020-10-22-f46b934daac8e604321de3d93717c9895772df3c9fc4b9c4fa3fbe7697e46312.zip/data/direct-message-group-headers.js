window.YTD.direct_message_group_headers.part0 = [ {
  "dmConversation" : {
    "conversationId" : "640762934029885440",
    "messages" : [ {
      "messageCreate" : {
        "id" : "640954746682101764",
        "senderId" : "51741625",
        "createdAt" : "2015-09-07T18:28:14.649Z"
      }
    }, {
      "messageCreate" : {
        "id" : "640950170037960707",
        "senderId" : "1217170945",
        "createdAt" : "2015-09-07T18:10:03.490Z"
      }
    }, {
      "messageCreate" : {
        "id" : "640831760058687491",
        "senderId" : "51741625",
        "createdAt" : "2015-09-07T10:19:32.349Z"
      }
    }, {
      "messageCreate" : {
        "id" : "640830359156981763",
        "senderId" : "1217170945",
        "createdAt" : "2015-09-07T10:13:58.355Z"
      }
    }, {
      "messageCreate" : {
        "id" : "640819225783877635",
        "senderId" : "1044385958",
        "createdAt" : "2015-09-07T09:29:43.945Z"
      }
    }, {
      "messageCreate" : {
        "id" : "640768856978493443",
        "senderId" : "51741625",
        "createdAt" : "2015-09-07T06:09:35.087Z"
      }
    }, {
      "messageCreate" : {
        "id" : "640762934029885443",
        "senderId" : "1217170945",
        "createdAt" : "2015-09-07T05:46:03.038Z"
      }
    }, {
      "joinConversation" : {
        "initiatingUserId" : "1217170945",
        "participantsSnapshot" : [ "39066509", "51741625", "1044385958", "1217170945", "111622431" ],
        "createdAt" : "2015-09-07T05:46:03.038Z"
      }
    } ]
  }
} ]