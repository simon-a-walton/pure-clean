window.YTD.account_timezone.part0 = [ {
  "accountTimezone" : {
    "accountId" : "1044385958",
    "timeZone" : "Amsterdam"
  }
} ]