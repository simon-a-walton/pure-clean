window.YTD.profile.part0 = [ {
  "profile" : {
    "description" : {
      "bio" : "Actor, Singer and Wellbeing Coach. https://t.co/AKEedv8GU8… Represented by @akagentslondon",
      "website" : "https://t.co/A3c3BvF5JC",
      "location" : "London"
    },
    "avatarMediaUrl" : "https://pbs.twimg.com/profile_images/973583847144280066/8um7-gaZ.jpg",
    "headerMediaUrl" : "https://pbs.twimg.com/profile_banners/1044385958/1520961891"
  }
} ]