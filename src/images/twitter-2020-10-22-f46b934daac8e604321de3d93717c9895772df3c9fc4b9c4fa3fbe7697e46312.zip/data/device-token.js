window.YTD.device_token.part0 = [ {
  "deviceToken" : {
    "clientApplicationId" : "49152",
    "token" : "N034z0Z9Sm6QF9bo8xh2Bxl6dLVLWGB0HpwcPdm3",
    "createdAt" : "2020-05-16T08:11:50.843Z",
    "lastSeenAt" : "2020-05-16T08:11:50.845Z",
    "clientApplicationName" : "Mobile Web (Twitter)"
  }
}, {
  "deviceToken" : {
    "clientApplicationId" : "49152",
    "token" : "mVuMzBTQ43Xmfgt6pSGfBEypmZerWRjfaYwKTQHU",
    "createdAt" : "2020-05-26T10:16:18.222Z",
    "lastSeenAt" : "2020-05-26T10:16:18.224Z",
    "clientApplicationName" : "Mobile Web (Twitter)"
  }
}, {
  "deviceToken" : {
    "clientApplicationId" : "3033300",
    "token" : "lS9OxV2Wn83ELUaXz2YHg61sPCyKCaHIiZkLTx8O",
    "createdAt" : "2020-10-21T08:31:52.823Z",
    "lastSeenAt" : "2020-10-21T08:31:52.825Z",
    "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
  }
} ]